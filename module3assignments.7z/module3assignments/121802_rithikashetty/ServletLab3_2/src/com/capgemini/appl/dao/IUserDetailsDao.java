package com.capgemini.appl.dao;

import com.capgemini.appl.entities.UserDetails;
import com.capgemini.appl.exception.UserException;

public interface IUserDetailsDao {
	
	
	public boolean addUseDetails(UserDetails userd) throws UserException;
	

}
