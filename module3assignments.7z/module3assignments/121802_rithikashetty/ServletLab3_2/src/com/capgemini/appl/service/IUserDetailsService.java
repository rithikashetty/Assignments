package com.capgemini.appl.service;

import com.capgemini.appl.entities.UserDetails;
import com.capgemini.appl.exception.UserException;

public interface IUserDetailsService {

	public boolean addUserDetails(UserDetails userd) throws UserException;
	
}
