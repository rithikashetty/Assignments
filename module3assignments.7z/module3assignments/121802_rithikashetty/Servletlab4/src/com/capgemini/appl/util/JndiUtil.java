package com.capgemini.appl.util;

import java.sql.Connection;
import java.sql.SQLException;




import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.capgemini.appl.exception.UserException;



public class JndiUtil {
	public static Connection obtainConnection() throws UserException{
		Connection conn = null;
		InitialContext context;
		
		try {
			context=new InitialContext();  
			DataSource datasource=(DataSource) context.lookup("java:/OracleDS");
			conn=datasource.getConnection();
			
		} catch (NamingException e) {
				e.printStackTrace();
		} catch (SQLException e) {
			    e.printStackTrace();
				throw new UserException("Problem in Connection");
		}
		return conn;
	}
	
}


