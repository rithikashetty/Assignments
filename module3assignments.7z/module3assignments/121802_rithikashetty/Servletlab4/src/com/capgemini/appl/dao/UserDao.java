package com.capgemini.appl.dao;

import java.util.List;

import com.capgemini.appl.entities.User;
import com.capgemini.appl.exception.UserException;

public interface UserDao {

	boolean AddUserData(User user)throws UserException;
	List<User> getUserDetail()throws UserException;
}
