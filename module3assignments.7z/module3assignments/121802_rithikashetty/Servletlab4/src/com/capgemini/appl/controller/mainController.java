package com.capgemini.appl.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.appl.entities.User;
import com.capgemini.appl.exception.UserException;
import com.capgemini.appl.service.UserService;
import com.capgemini.appl.service.UserServiceImpl;

@WebServlet("/main")
public class mainController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	UserService service;
	User user;
	private RequestDispatcher dispatcher;

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
           doPost(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		List<User> list;
		try {
			service = new UserServiceImpl();
		} catch (UserException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		System.out.println("hiii");
		System.out.println(service);
		boolean result;
		char gen;
		String skillSet = null;
		String skillFinal = null;
		user = new User();
		String fname = request.getParameter("fname");
		String lname = request.getParameter("lname");
		String pwd = request.getParameter("pass");
		String gender = request.getParameter("Gender");
		String[] skill = request.getParameterValues("skill");
		String city = request.getParameter("city");
		/*
		 * StringBuilder sb=new StringBuilder(); for(String a : skill){
		 * sb.append(a); } skillFinal=sb.toString();
		 */

		String skills = "";
		for (int i = 0; i < skill.length; i++) {
			skills = skills.concat(skill[i]);
		}

		if (gender == "Female") {
			gen = 'F';
		} else {
			gen = 'M';
		}

		user.setFname(fname);
		user.setLname(lname);
		user.setPassword(pwd);
		user.setGender(gen);
		user.setSkillset(skills);
		user.setCity(city);

		try {
			result = service.AddUserData(user);
			if (result == true) {
				log("Data Inserted Successfully");
				list=service.getUserDetail();
				request.setAttribute("Fname",fname);
				request.setAttribute("UserList",list);
				dispatcher = request.getRequestDispatcher("success.jsp");
				dispatcher.forward(request, response);

				
				/*for (User u : list) {
						String fnameDB=u.getFname();
						String lnameDb=u.getLname();
						String pwdDb=u.getPassword();
						char genderDb=u.getGender();
						String skillDb=u.getSkillset();
						String cityDb=u.getCity();
						
						request.setAttribute("fname", fnameDB);
						request.setAttribute("lname", lnameDb);
						request.setAttribute("pwd", pwdDb);
						request.setAttribute("gender", genderDb);
						request.setAttribute("skillset", skillDb);
						request.setAttribute("city", cityDb);
						
				}	
				*/
				
				
				
			
			} else {
				log("Data Not Inserted In DB");
				response.sendRedirect("fail.html");
			}
		} catch (UserException e) {

			e.printStackTrace();
		}
	}

}
