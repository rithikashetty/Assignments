package com.cg.ebill.dto;

import java.sql.Date;

public class BillDetails {

private int billno;
private int consumerno;
private int crntreading;
private int unitconsumed;
private int netamount;
private Date date;
@Override
public String toString() {
	return "BillDetails [billno=" + billno + ", consumerno=" + consumerno
			+ ", crntreading=" + crntreading + ", unitconsumed=" + unitconsumed
			+ ", netamount=" + netamount + ", date=" + date + "]";
}
public BillDetails() {
	super();
}
public BillDetails(int billno, int consumerno, int crntreading,
		int unitconsumed, int netamount, Date date) {
	super();
	this.billno = billno;
	this.consumerno = consumerno;
	this.crntreading = crntreading;
	this.unitconsumed = unitconsumed;
	this.netamount = netamount;
	this.date = date;
}
public int getBillno() {
	return billno;
}
public void setBillno(int billno) {
	this.billno = billno;
}
public int getConsumerno() {
	return consumerno;
}
public void setConsumerno(int consumerno) {
	this.consumerno = consumerno;
}
public int getCrntreading() {
	return crntreading;
}
public void setCrntreading(int crntreading) {
	this.crntreading = crntreading;
}
public int getUnitconsumed() {
	return unitconsumed;
}
public void setUnitconsumed(int unitconsumed) {
	this.unitconsumed = unitconsumed;
}
public int getNetamount() {
	return netamount;
}
public void setNetamount(int netamount) {
	this.netamount = netamount;
}
public Date getDate() {
	return date;
}
public void setDate(Date date) {
	this.date = date;
}


}
