package com.cg.ebill.service;

import java.util.List;

import com.cg.ebill.dto.BillDetails;
import com.cg.ebill.dto.Consumer;
import com.cg.ebill.dto.User;
import com.cg.ebill.exception.BillException;

public interface IEbillService {

	User getUserDetails(String userName) throws BillException; //throws BillException;
	boolean isUserAuthenticated(String username,String password) throws BillException; //throws BillException;
	public List<Consumer>showAll() throws BillException;//throws BillException
    public	Consumer searchConsumer(int consumerno) throws BillException;
    public List<BillDetails> getConsumerNo(int cno) throws BillException;
    public int addBillDetail(int consumerno, BillDetails billDetail) throws BillException;
	
}
