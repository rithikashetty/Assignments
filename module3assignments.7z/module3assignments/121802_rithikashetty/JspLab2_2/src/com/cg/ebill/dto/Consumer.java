package com.cg.ebill.dto;

public class Consumer {

	private int consumerNo;
	private String consumername;
	private String address;
	public int getConsumerNo() {
		return consumerNo;
	}
	public void setConsumerNo(int consumerNo) {
		this.consumerNo = consumerNo;
	}
	public String getConsumername() {
		return consumername;
	}
	public void setConsumername(String consumername) {
		this.consumername = consumername;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Consumer(int consumerNo, String consumername, String address) {
		super();
		this.consumerNo = consumerNo;
		this.consumername = consumername;
		this.address = address;
	}
	public Consumer() {
		super();
	}
	@Override
	public String toString() {
		return "Consumer [consumerNo=" + consumerNo + ", consumername="
				+ consumername + ", address=" + address + "]";
	}

}
