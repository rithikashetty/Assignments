package com.cg.appl.DateTime;

import java.io.IOException;

import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/dateTimeServlet")
public class DateTimeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
		Date dateobj = new Date();
		System.out.println(df.format(dateobj));
		PrintWriter out = response.getWriter();
		out.write("Date And Time:"+df.format(dateobj));
		
		
	}




	public void destroy() {
		System.out.println("In destroy()");
		super.destroy();//when undeployment is done then this method runs once
		
	}


	public void init(ServletConfig config) throws ServletException {
		
		super.init();
		System.out.println("In Init()");//when deployment is done then this method runs only once
	}

}
