package com.cg.appl.dao;



import com.cg.appl.UserException.UserException;

public interface UserMasterDao {
	com.cg.appl.entities.User getUserDetails(String userName) throws UserException;

}
