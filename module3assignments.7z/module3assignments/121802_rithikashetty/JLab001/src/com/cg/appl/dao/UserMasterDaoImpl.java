package com.cg.appl.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.appl.UserException.UserException;
import com.cg.appl.entities.User;
import com.cg.appl.util.*;

public class UserMasterDaoImpl implements UserMasterDao {
	private JdbcUtill jdbcUtill = null;

	public UserMasterDaoImpl() {

	}

	@Override
	public User getUserDetails(String userName) throws UserException {
	PreparedStatement stat = null;
	Connection connection = null;
	ResultSet rs = null;
		jdbcUtill=new JdbcUtill();
		String Query="select username,password,userfname from usermaster where username=? ";
		try {

			connection=jdbcUtill.getConnection();
			stat=connection.prepareStatement(Query);
			stat.setString(1, userName);
			rs=stat.executeQuery();
			if(rs.next())
			{
				String Password=rs.getString("password");
				String userfname=rs.getString("userfname");
				User usrUser=new User(userName, Password, userfname);
				return usrUser;
			}
			else{
				throw new UserException("Wrong user Name");
			}
			
		} catch (SQLException e) {
			throw new UserException("JDBC FAILED");
		}
	finally{
		if(rs!=null)
		{
			try {
				rs.close();
				if(stat!=null)
				{
					stat.close();
				}
				if(connection!=null)
				{
					connection.close();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
			//	e.printStackTrace();
				throw new UserException("Connection Closing failed");
			}
		}
		
	}
	}
}
