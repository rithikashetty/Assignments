package com.cg.appl.servlets;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/authenticate")
public class Authenticate extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void init(ServletConfig config) throws ServletException {

	}




	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("in servlet");
		String user="asha";
		String pass="asha";
		String uName=request.getParameter("username");
		String passwrd=request.getParameter("password");
		String nextJsp = null;
		String message=null;
		
		if((user.equals(uName))&&(pass.equals(passwrd))){
			response.sendRedirect("success.jsp");
			//nextJsp="/success.jsp";
			
		}else{
			
			message="Wrong Credentials.Enter again";
			request.setAttribute("errorMsg", message);
			response.sendRedirect("failure.jsp");
		}
		
	}
	public void destroy() {
		// TODO Auto-generated method stub
	}

}
