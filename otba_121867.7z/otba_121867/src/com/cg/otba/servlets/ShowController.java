package com.cg.otba.servlets;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.otba.entities.Shows;
import com.cg.otba.entities.customers;
import com.cg.otba.exceptions.BookingException;
import com.cg.otba.services.ITicketBookingService;
import com.cg.otba.services.TicketBookingServiceImpl;

@WebServlet("*.do")
public class ShowController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ITicketBookingService services;
	private String nextJsp=null;
	private String message=null;
	private RequestDispatcher dispatch;


	public void init() throws ServletException {
		services = new TicketBookingServiceImpl();
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		try {
			processRequest(request, response);
		} catch (ParseException | BookingException e) {
			e.printStackTrace();
		}
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		try {
			processRequest(request, response);
		} catch (ParseException | BookingException e) {
			e.printStackTrace();
		}
	}

	private void processRequest(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException, ParseException, BookingException{
		String path = request.getServletPath();
		
		switch (path) {
			case "/showcontroller.do" :{
				List<Shows> sList = null;
				
				try {
					sList = services.ShowAll();
					HttpSession session = request.getSession(true);	// If session already exists still creates a new session
					
					session.setAttribute("data", sList);		// session scope
					nextJsp = "showDetails.jsp";
				} catch (BookingException e) {
					e.printStackTrace();
					throw new BookingException("error in displaying show details");
					
				}
				break;
			}
			case "/booknow.do": {
				
				String data = request.getQueryString();
				String showid = data.substring(3, 7);
			
				try {
					Shows detail = services.getShowDetails(showid);
					
					request.setAttribute("sData", detail);
					nextJsp = "bookNow.jsp";
				} catch (BookingException e) {
					e.printStackTrace();
					throw new BookingException("unable to get query string");
					
				}
				break;
			}
			case "/updatedata.do": {
				
				String name = request.getParameter("name");
				String price = request.getParameter("price");
				String cname = request.getParameter("cname");
				String phoneno = request.getParameter("phoneno");
				String seats =  request.getParameter("seats");
				String noseats = request.getParameter("noseats");
				
				int avseats = Integer.parseInt(seats);
				int seat = Integer.parseInt(noseats);
				if(avseats>= seat){
				Shows show = new Shows();
				customers cust = new customers();
				
				show.setShowname(name);
				show.setPricetickets(Double.parseDouble(price));
				
				cust.setCustomername(cname);
				cust.setC_phoneno(phoneno);
				
				try {
					boolean result = services.updateData(show,seat);
					if(result){
						request.setAttribute("sData", show);		//show data
						request.setAttribute("cData", cust);		//customer details
						request.setAttribute("noofseats", seat); 	//no of seats
						
						nextJsp = "/success.jsp";
					}else {
						message = "Error in booking show tickets..sorry for inconvinence";
						request.setAttribute("errorMsg", message);
						nextJsp = "error.jsp";
					}
				} catch (BookingException e) {
					e.printStackTrace();
					throw new BookingException("unable to book ticket");
					
				}
				}else {
					message = "not enough seats..";
					request.setAttribute("errorMsg", message);
				}
						
				break;
			}
			
		}
		dispatch = request.getRequestDispatcher(nextJsp);
		dispatch.forward(request, response);
	}

	public void destroy() {
		services = null;
	}

}
