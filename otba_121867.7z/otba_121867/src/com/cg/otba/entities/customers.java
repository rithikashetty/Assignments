package com.cg.otba.entities;

public class customers {
	private String customername;
	private String c_phoneno;

	public customers() {
		super();
	}

	public customers(String customername, String c_phoneno) {
		super();
		this.customername = customername;
		this.c_phoneno = c_phoneno;
	}

	public String getCustomername() {
		return customername;
	}

	public void setCustomername(String customername) {
		this.customername = customername;
	}

	public String getC_phoneno() {
		return c_phoneno;
	}

	public void setC_phoneno(String c_phoneno) {
		this.c_phoneno = c_phoneno;
	}

	@Override
	public String toString() {
		return "customers [customername=" + customername + ", c_phoneno="
				+ c_phoneno + "]";
	}

}
