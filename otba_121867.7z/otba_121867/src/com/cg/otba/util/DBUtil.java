package com.cg.otba.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.otba.exceptions.BookingException;

public class DBUtil {
	public static Connection obtainConnection() throws BookingException {
		Connection conn = null;
		InitialContext context;
		try {
			context = new InitialContext();
			DataSource source = (DataSource) context.lookup("java:/OracleDS");
			conn = source.getConnection();
		} catch (NamingException | SQLException e) {
			e.printStackTrace();
			throw new BookingException("Problem in connection");

		}
		return conn;
	}
}
