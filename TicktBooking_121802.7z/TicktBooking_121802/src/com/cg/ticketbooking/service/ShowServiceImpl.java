package com.cg.ticketbooking.service;

import java.util.List;

import com.cg.ticketbooking.dao.ShowDao;
import com.cg.ticketbooking.dao.ShowDaoImpl;
import com.cg.ticketbooking.dto.Show;
import com.cg.ticketbooking.exception.TicketBookException;

public class ShowServiceImpl implements ShowService {
	
	ShowDao showdao;

	public ShowServiceImpl() {
		
		showdao= new ShowDaoImpl();
	}

	@Override
	public List<Show> showAll() throws TicketBookException {
		
		return showdao.showAll();
	}

	@Override
	public Show getShowId(String id) throws TicketBookException {
		// TODO Auto-generated method stub
		return showdao.getShowId(id);
	}

	@Override
	public boolean updateSeat(Show show1) throws TicketBookException {
		// TODO Auto-generated method stub
		return showdao.updateSeat(show1);
	}

}
