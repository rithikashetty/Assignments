package com.cg.ticketbooking.dto;

import java.sql.Date;

public class Show {
	
	private String showId;
	private String showName;
	private String loaction;
	private Date dt;
	private int availableSeats;
	private Double priceTckt;
	private String mobileNo;
	private String customerName;
	private int seatbook;
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public int getSeatbook() {
		return seatbook;
	}
	public void setSeatbook(int seatbook) {
		this.seatbook = seatbook;
	}
	public Show() {
		super();
	}
	public Show(String showId, String showName, String loaction, Date dt,
			int availableSeats, Double priceTckt,String mobileNo, String customerName, int seatbook) {
		super();
		this.showId = showId;
		this.showName = showName;
		this.loaction = loaction;
		this.dt = dt;
		this.availableSeats = availableSeats;
		this.priceTckt = priceTckt;
		this.mobileNo = mobileNo;
		this.customerName = customerName;
		this.seatbook = seatbook;
	}
	public String getShowId() {
		return showId;
	}
	public void setShowId(String showId) {
		this.showId = showId;
	}
	public String getShowName() {
		return showName;
	}
	public void setShowName(String showName) {
		this.showName = showName;
	}
	public String getLoaction() {
		return loaction;
	}
	public void setLoaction(String loaction) {
		this.loaction = loaction;
	}
	public Date getDt() {
		return dt;
	}
	public void setDt(Date dt) {
		this.dt = dt;
	}
	public int getAvailableSeats() {
		return availableSeats;
	}
	public void setAvailableSeats(int availableSeats) {
		this.availableSeats = availableSeats;
	}
	public Double getPriceTckt() {
		return priceTckt;
	}
	public void setPriceTckt(Double priceTckt) {
		this.priceTckt = priceTckt;
	}
	@Override
	public String toString() {
		return "Show [showId=" + showId + ", showName=" + showName
				+ ", loaction=" + loaction + ", dt=" + dt + ", availableSeats="
				+ availableSeats + ", priceTckt=" + priceTckt + ", mobileNo="
				+ mobileNo + ", customerName=" + customerName + ", seatbook="
				+ seatbook + "]";
	}
	
	

}
