package com.cg.ticketbooking.dao;

import java.sql.Connection;


import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.ticketbooking.dto.Show;
import com.cg.ticketbooking.exception.TicketBookException;
import com.cg.ticketbooking.util.DbUtil;

public class ShowDaoImpl implements ShowDao {

	public ShowDaoImpl() {
		

}

	@Override
	public List<Show> showAll() throws TicketBookException {
		Connection conn=null;
		PreparedStatement pstm=null;
		List<Show> myList = new ArrayList<Show>();
		String showQuery="SELECT showid, ShowName, Location, ShowDate, AvSeats, PriceTicket FROM ShowDetails";
		
		try {
			conn=DbUtil.obtainconnection();
			pstm=conn.prepareStatement(showQuery);
			
			ResultSet rs = pstm.executeQuery();
			
			while(rs.next()){
				
				Show show = new Show();
				show.setShowId(rs.getString("ShowId"));
				show.setShowName(rs.getString("ShowName"));
				show.setLoaction(rs.getString("Location"));
				show.setDt(rs.getDate("ShowDate"));
				show.setAvailableSeats(rs.getInt("AvSeats"));
				show.setPriceTckt(rs.getDouble("PriceTicket"));
				myList.add(show);
			}
			
		}catch (TicketBookException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new TicketBookException("Problem in show");
		}
		
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			//throw new TicketBookException("Problem in show");
		}
		finally{
			try{
				
				pstm.close();
				conn.close();
				
			}catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();	
		}
		}
		return myList;
	}

	@Override
	public Show getShowId(String id) throws TicketBookException {
		Connection conn=null;
		PreparedStatement pstm=null;
		Show show = new Show();
		String query="SELECT ShowId, ShowName,AvSeats, PriceTicket FROM ShowDetails WHERE ShowId=?";
		try {
			conn=DbUtil.obtainconnection();    //connection is build
			pstm=conn.prepareStatement(query);
			pstm.setString(1, id);
			ResultSet rs = pstm.executeQuery();  //query is executed here
			
			while(rs.next()){
				show.setShowId(rs.getString("ShowId"));
				show.setShowName(rs.getString("ShowName"));
				//show.setLoaction(rs.getString("Location"));
				//show.setDt(rs.getDate("ShowDate"));
				show.setAvailableSeats(rs.getInt("AvSeats"));
				show.setPriceTckt(rs.getDouble("PriceTicket"));
			}
			
		} catch (TicketBookException e) {
			
			e.printStackTrace();
			throw new TicketBookException("Problem Occured..");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			try{
				
				pstm.close();
				conn.close();
				
			}catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();	
		}
		}
		
		return show;
	}

	@Override
	public boolean updateSeat(Show show1) throws TicketBookException {
		
		Connection conn=null;
		PreparedStatement pstm=null;
		int status=0;
		int seat=0;
		String selectquery="SELECT AvSeats FROM ShowDetails WHERE ShowId=? ";
		String updatequery="UPDATE ShowDetails SET AvSeats=AvSeats-? WHERE ShowId=?";
		
		
			try {
				conn=DbUtil.obtainconnection();
				pstm=conn.prepareStatement(selectquery);
				pstm.setString(1,show1.getShowId());
				ResultSet rs=pstm.executeQuery();
				
				while(rs.next()){
				seat=rs.getInt(1);	
					
				}
				
			} catch (TicketBookException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			try {
				if(seat >show1.getSeatbook()){
					conn=DbUtil.obtainconnection();
					pstm=conn.prepareStatement(updatequery);
					pstm.setInt(1,show1.getSeatbook());
					pstm.setString(2,show1.getShowId());
					status=pstm.executeUpdate();
					
					if(status>0){
						System.out.println("data is updated");
						/*
						String query="SELECT ShowName,AvSeats, PriceTicket FROM ShowDetails WHERE ShowId=? ";
						pstm.setString(1,show1.getShowId());*/
						
						return true;
					}
					
					
				}
			
			} catch (TicketBookException e) {
				throw new TicketBookException("You cant book seats",e);
				//e.printStackTrace()
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
				

		
		return false;
	}


	
}
