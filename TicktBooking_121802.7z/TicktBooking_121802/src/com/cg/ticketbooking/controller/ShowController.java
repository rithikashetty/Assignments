package com.cg.ticketbooking.controller;

import java.io.IOException;




import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.ticketbooking.dto.Show;
import com.cg.ticketbooking.exception.TicketBookException;
import com.cg.ticketbooking.service.ShowService;
import com.cg.ticketbooking.service.ShowServiceImpl;


@WebServlet("*.do")//showController
public class ShowController extends HttpServlet {
	private static final long serialVersionUID = 1L;
      ShowService showService;

    public ShowController() {
        showService = new ShowServiceImpl();
    }

	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}


	public void destroy() {
		// TODO Auto-generated method stub
	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request,response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request,response);
	}

	private void processRequest(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{
		
		String path= request.getServletPath();
		System.out.println(path);
		
		
		if(path.equals("/showcontroller.do")){
			
	
				RequestDispatcher rs= request.getRequestDispatcher("/showDetails.do");
				rs.forward(request,response);
				
			
		}else if(path.equals("/showDetails.do")){
			List<Show> myList = null;
			try {
				
				
				myList=showService.showAll();
				
				System.out.println(myList);
			} catch (TicketBookException e) {
				System.out.println("Error while displaying show details");
				e.printStackTrace();
			}
			
			
			request.setAttribute("data", myList);
			RequestDispatcher req = request.getRequestDispatcher("showDetails.jsp");
			req.forward(request, response);
		}
		else if(path.equals("/bookNow.do")){
			
			String data=request.getQueryString();
			System.out.println(data);
			String id=data.substring(3,7);
			System.out.println("id="+id);
			
			
			Show show=null;
			
			try {
				show=showService.getShowId(id);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			request.setAttribute("emp", show);
			RequestDispatcher reqs =request.getRequestDispatcher("bookNow.jsp");
			reqs.forward(request,response);
		}
		else if(path.equals("/bookednow.do")){
			
			Show show1 = new Show();
			//retiving values from bookNow.jsp page
			String showid=request.getParameter("showid");
			String showname=request.getParameter("showname");
			String priceTickt=request.getParameter("price");
			String custname=request.getParameter("custname");
			String mobileno=request.getParameter("mobileno");
			String avaiseat1=request.getParameter("avseats");
			String noofseat=request.getParameter("seatbook");
			int avaiseat=Integer.parseInt(avaiseat1);
			show1.setShowId(showid);
			show1.setShowName(showname);
			show1.setPriceTckt(Double.parseDouble(priceTickt));
			show1.setCustomerName(custname);
			show1.setMobileNo(mobileno);
			show1.setAvailableSeats(avaiseat);
			show1.setSeatbook(Integer.parseInt(noofseat));
			
			boolean val;
			try {
				val = showService.updateSeat(show1);
				System.out.println(val);
				
				if(val==true){
					request.setAttribute("show", show1);
					RequestDispatcher req = request.getRequestDispatcher("success.jsp");
					req.forward(request, response);
				}
				else{
					
					RequestDispatcher req = request.getRequestDispatcher("error.jsp");
					req.forward(request, response);
				}
			} catch (TicketBookException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
/*			
			if(val==true){
				request.setAttribute("show", show1);
				RequestDispatcher req = request.getRequestDispatcher("success.jsp");
				req.forward(request, response);
			}
			else{
				
				RequestDispatcher req = request.getRequestDispatcher("error.jsp");
				req.forward(request, response);
			}*/
		}
		
	}
}
