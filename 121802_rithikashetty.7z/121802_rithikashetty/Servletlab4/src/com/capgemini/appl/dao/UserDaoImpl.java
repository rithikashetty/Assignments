package com.capgemini.appl.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.appl.entities.User;
import com.capgemini.appl.exception.UserException;
import com.capgemini.appl.util.JndiUtil;

public class UserDaoImpl implements UserDao{
 JndiUtil util;
	
	public UserDaoImpl() throws UserException {
		util=new JndiUtil();		
	}
	
	@Override
	public boolean AddUserData(User user) throws UserException {
		Connection conn = null;
		PreparedStatement pstm = null;
		int rec=0;
		String query="INSERT INTO RegisteredUsers(firstname,lastname,password,gender,skillset,city) VALUES(?,?,?,?,?,?)";
		String fname=user.getFname();
		String lname=user.getLname();
		String pwd=user.getPassword();
		char gender=user.getGender();
		String skill=user.getSkillset();
		String city=user.getCity();
		
		try {
			conn=util.obtainConnection();
			pstm=conn.prepareStatement(query);
			pstm.setString(1,fname);
			pstm.setString(2,lname);
			pstm.setString(3,pwd);
			pstm.setString(4,String.valueOf(gender));
			pstm.setString(5,skill);
			pstm.setString(6,city);
			rec=pstm.executeUpdate();
			if(rec>0){
				return true;
			}else {
				return false;
			}
			
			
		} catch (SQLException e) {
			
			throw new UserException("User Data Not Inserted",e);
		}
	
	}

	@Override
	public List<User> getUserDetail() throws UserException {
		List<User> list=new ArrayList<User>();
		Connection conn = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;
		String query ="SELECT * FROM RegisteredUsers";
		
		
		try {
			conn= util.obtainConnection();
			pstm=conn.prepareStatement(query);
			rs=pstm.executeQuery();
			
			if(rs.next()){
				String fname=rs.getString("firstname");
				String lname=rs.getString("lastname");
				String pwd=rs.getString("password");
				String gender=rs.getString("gender");
				String skill=rs.getString("skillset");
				String city=rs.getString("city");
				char gen=gender.charAt(1);
				System.out.println(gen);
			
			User user=new User(fname,lname,pwd,gen,skill,city);
			list.add(user);
				return list;
				
			}else{
			
			throw new UserException("No Data Selected");
			}
			
			
		} catch (SQLException e) {
			
			   throw new UserException("No jdbc connection",e);
				
		}
		finally{
		
			try {
				if(rs!=null){
				  rs.close();
				}
				if(pstm!=null){
				pstm.close();
				}
				if(conn!=null){
				conn.close();
				}
			} catch (SQLException e) {
				
				throw new UserException("jdbc connection closing failed");
			}
		}
	
		
		
		
	}

}
