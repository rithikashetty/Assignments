package com.capgemini.appl.entities;

import java.io.Serializable;

public class User implements Serializable{

	private static final long serialVersionUID = 1L;
	private String fname;
	private String lname;
	private String password;
	private char gender;
	private String skillset;
	private String city;
	
	@Override
	public String toString() {
		return "User [fname=" + fname + ", lname=" + lname + ", password="
				+ password + ", gender=" + gender + ", skillset=" + skillset
				+ ", city=" + city + "]";
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public char getGender() {
		return gender;
	}

	public void setGender(char gender) {
		this.gender = gender;
	}

	public String getSkillset() {
		return skillset;
	}

	public void setSkillset(String skillset) {
		this.skillset = skillset;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public User() {
		super();
	}

	public User(String fname, String lname, String password, char gender,
			String skillset, String city) {
		super();
		this.fname = fname;
		this.lname = lname;
		this.password = password;
		this.gender = gender;
		this.skillset = skillset;
		this.city = city;
	}
}
