package com.capgemini.appl.service;

import java.util.List;

import com.capgemini.appl.dao.UserDao;
import com.capgemini.appl.dao.UserDaoImpl;
import com.capgemini.appl.entities.User;
import com.capgemini.appl.exception.UserException;

public class UserServiceImpl implements UserService{

	UserDao dao;
	public UserServiceImpl() throws UserException {
	dao=new UserDaoImpl();	
	}
	
	@Override
	public boolean AddUserData(User user) throws UserException {
		
		return dao.AddUserData(user);
	}

	@Override
	public List<User> getUserDetail()throws UserException{
		return dao.getUserDetail();
	}
	}
		
	

	

