package com.capgemini.appl.service;

import java.util.List;

import com.capgemini.appl.entities.User;
import com.capgemini.appl.exception.UserException;

public interface UserService {

	boolean AddUserData(User user)throws UserException;
	public List<User> getUserDetail()throws UserException;
}
