package com.cg.appl.Services;

import com.cg.appl.UserException.UserException;
import com.cg.appl.dao.UserMasterDaoImpl;
import com.cg.appl.entities.User;

public class UserMasterServicesImpl implements UserMasterServices {

	UserMasterDaoImpl daoImpl;
	public UserMasterServicesImpl() {
		 daoImpl=new UserMasterDaoImpl();	}

	@Override
	public User getUserDetails(String userName) throws UserException {
		// TODO Auto-generated method stub
		return daoImpl.getUserDetails(userName);
	}

	@Override
	public boolean isUserAuthenticated(String username, String Password)
			throws UserException {
		User user=daoImpl.getUserDetails(username);
		if(Password.equals(user.getPassword()))
		{
			return true;
		}
		else	return false;
	}

}
