package com.cg.appl.servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import javax.security.auth.message.callback.PrivateKeyCallback.Request;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.appl.Services.UserMasterServicesImpl;
import com.cg.appl.UserException.UserException;
import com.cg.appl.util.JdbcUtill;
import com.sun.org.apache.xalan.internal.xsltc.compiler.util.ErrorMsg;

@WebServlet("/authenticate")
public class Authenticate extends HttpServlet {
	private static final long serialVersionUID = 1L;
	UserMasterServicesImpl service;
	Connection con = null;
	JdbcUtill jdbcUtill;

	public void init() throws ServletException {
		service = new UserMasterServicesImpl();
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse resp)
			throws ServletException, IOException {
		String uString = request.getParameter("userName");
		String password = request.getParameter("password");
		RequestDispatcher dispatcher;
		String nextjsp = null;
		String msg=null;
		try {

			boolean isAuthenticated = service.isUserAuthenticated(uString,
					password);

			if (isAuthenticated) {
				System.out.println("YES");
				/*
				 * dispatcher = request.getRequestDispatcher("/mainMenu.jsp");
				 * dispatcher.forward(request, resp);
				 */
				nextjsp = "/mainMenu.jsp";
			} else {
				System.out.println("NO");
				/*
				 * dispatcher = request.getRequestDispatcher("/login.jsp");
				 * dispatcher.forward(request, resp);
				 */
				msg="Wrong Credential...Enter Again";
				request.setAttribute("errorMsg",msg);
				nextjsp = "/login.jsp";
			}

		} catch (UserException e) {
			/*
			 * dispatcher = request.getRequestDispatcher("/error.jsp");
			 * dispatcher.forward(request, resp);
			 */
			msg="User Name doest not exist";
			request.setAttribute("errorMsg",msg);
			nextjsp = "/error.jsp";
			// TODO Auto-generated catch block
			// e.printStackTrace();
		}

		dispatcher = request.getRequestDispatcher(nextjsp);
		dispatcher.forward(request, resp);

		if (con != null) {
			System.out.println("Connected");
		}
		System.out.println(uString + " " + password);
	}

	public void destroy() {
		// TODO Auto-generated method stub
	}

}
