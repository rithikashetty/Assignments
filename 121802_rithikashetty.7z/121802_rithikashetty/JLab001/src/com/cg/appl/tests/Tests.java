package com.cg.appl.tests;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.appl.Services.UserMasterServicesImpl;
import com.cg.appl.UserException.UserException;
import com.cg.appl.entities.User;

public class Tests {
	private static UserMasterServicesImpl service;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		service = new UserMasterServicesImpl();
	}

	@Test
	public void testGetUserDetails() {
		User user = new User("a", "a", "aa");
		try {
			assertEquals(service.getUserDetails("a").getPassword(), user.getPassword());
		} catch (UserException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
