package com.cg.ebill.dto;

import java.sql.Date;

public class BillDetails {
private int billno;
private int consumerNo;
private float crntmnthread;
private float unitconsumed;
private float netamount;
private Date dt;
public int getBillno() {
	return billno;
}
public void setBillno(int billno) {
	this.billno = billno;
}
public int getConsumerNo() {
	return consumerNo;
}
public BillDetails() {
	super();
}

public BillDetails(int billno, int consumerNo, float crntmnthread,
		float unitconsumed, float netamount, Date dt) {
	super();
	this.billno = billno;
	this.consumerNo = consumerNo;
	this.crntmnthread = crntmnthread;
	this.unitconsumed = unitconsumed;
	this.netamount = netamount;
	this.dt = dt;
}
public void setConsumerNo(int consumerNo) {
	this.consumerNo = consumerNo;
}
public float getCrntmnthread() {
	return crntmnthread;
}
public void setCrntmnthread(float crntmnthread) {
	this.crntmnthread = crntmnthread;
}
public float getUnitconsumed() {
	return unitconsumed;
}
public void setUnitconsumed(float unitconsumed) {
	this.unitconsumed = unitconsumed;
}
public float getNetamount() {
	return netamount;
}
public void setNetamount(float netamount) {
	this.netamount = netamount;
}
public Date getDt() {
	return dt;
}
public void setDt(Date dt) {
	this.dt = dt;
}

@Override
public String toString() {
	return "BillDetails [billno=" + billno + ", consumerNo=" + consumerNo
			+ ", crntmnthread=" + crntmnthread + ", unitconsumed="
			+ unitconsumed + ", netamount=" + netamount + ", dt=" + dt + "]";
}
}
