package com.capgemini.appl.service;

import com.capgemini.appl.dao.IUserDetailsDao;
import com.capgemini.appl.dao.UserDetailsDaoImpl;
import com.capgemini.appl.entities.UserDetails;
import com.capgemini.appl.exception.UserException;

public class UserDetailsServiceImpl implements IUserDetailsService {

	IUserDetailsDao udao;
	public UserDetailsServiceImpl() {
		udao = new UserDetailsDaoImpl();
	}

	@Override
	public boolean addUserDetails(UserDetails userd) throws UserException {
		
		return udao.addUseDetails(userd);
	}

}
