package com.cg.app.servlet;

import java.io.IOException;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.app.service.Mydate;

@WebServlet("*.do")
public class First extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private RequestDispatcher requestDispatcher;
	private String nextJspString;

	public First() {
		super();
	}

	private void processRequest(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		String command = request.getServletPath();
		System.out.println(command);

		switch (command) {
		case "/insert.do": {
			Mydate dMydate = new Mydate();
			String d = request.getParameter("mydate").toString();
			System.out.println(d);
			// //////////////////////
			try {
				SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
				java.util.Date date = sdf1.parse(d);
				java.sql.Date sqlStartDate = new Date(date.getTime());
				System.out.println(sqlStartDate);
				
				/////
				dMydate.insertdate(sqlStartDate);
				/////
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			// //////////

			
			nextJspString = "/show.jsp";
		}
			break;
			
		case "/getdate.do":
			Mydate dMydate=new Mydate();
			System.out.println("INSERTED IN GETDATE");
			List<java.sql.Date> date=	dMydate.getDate();
			System.out.println("LEAVING IN GETDATE");
			System.out.println(date);
			request.setAttribute("date", date);
			nextJspString="/show.jsp";
		break;
		}
		requestDispatcher = request.getRequestDispatcher(nextJspString);
		requestDispatcher.forward(request, response);
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

}
