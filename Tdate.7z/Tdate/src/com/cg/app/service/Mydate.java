package com.cg.app.service;

import java.sql.Date;
import java.util.List;

public class Mydate {
	com.cg.app.dao.Mydate dMydate=new com.cg.app.dao.Mydate();
	
	public Boolean insertdate(Date d) {
		return dMydate.insertdate(d);
		
	}
	public List<java.sql.Date> getDate() {
		return dMydate.getDate();
	}

}
