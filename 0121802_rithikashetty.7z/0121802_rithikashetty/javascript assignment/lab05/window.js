function getWindow(){

var v_width= document.mywindow.wd.value;
var v_height= document.mywindow.ht.value;
var v_left= document.mywindow.lft.value;
var v_top= document.mywindow.tp.value;

 //myWindow = window.open("", "MsgWindow", "width="+v_width+",height="+v_height);
 
 myWindow = window.open("", "MsgWindow",'width=' + v_width + ', height=' + v_height + ', top=' + v_top + ', left=' + v_left);
 myWindow.document.write("The window is opened on clicking of the New Window button");
 
 
 
 }