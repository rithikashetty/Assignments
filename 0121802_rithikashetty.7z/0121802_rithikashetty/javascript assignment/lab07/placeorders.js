function placeOrder(){
alert('hii')
var qt1= document.orderproduct.dollqty.value;
var qt2= document.orderproduct.calqty.value;
var qt3=document.orderproduct.mobqty.value;
var qt4=document.orederproduct.lgqty.value;
var singletotal;
var total=0;
var qty_ar= new Array(qt1,qt2,qt3,qt4);

var price1=20;
var price2=30;
var price3=40;
var price4=50;

var pricear = new Array(pice1,price2,price3,price4);

var product1="Barbie doll";
var product2="calculator";
var product3="mobile phone";
var product4="LG DVD";
var productar= new Array(product1,product2,product3,product4);
 document.write("print product array :"+productar+"<br>");
 document.write("print price array :"+pricear+"<br>");
document.write("print qty_ar array :"+qty_ar+"<br>");
document.write("<br>");

if((qt1==null ||qt1=="")&&(qt2==null||qt2=="")&&(qt3==null||qt3=="")&&(qt4==null||qt4==""))
{
	alert("No Items Selected");
}
myWindow = window.open("","MsgWindow","width=500,height="500");
myWindow.document.write("<p align=center>INVOICE</p>");
myWindow.document.write("<table border=1 align=center><tr><td>PRODUCT</td> <td> Quantity</td><td>Price</td><td>TOTAL</td>"");
for(var i=0; i< qty_ar.length;i++)
{
	if(qty_ar[i]!=null && qty_ar[i]!=""){
		singletotal=qty_ar[i]*pricear[i];
		myWindow.document.write("<tr><td>"+productar[i]+"</td><td>"+qty_ar[i]+"</td><td>"+pricear[i]+"</td></td>"+singletotal+"</td></tr>");
		total=total+singletotal;
	}
}
mywindow.documnet.window("<tr><td>Total Bill</td><td></td><td></td>+"total"+<td></td>");
myWindow.documnet.write("</table>");
}