var myWindow2;
var age;
var ab;
var phn;
var mailid;
var grdLevel;
var qual;

	
//ab= document.formValidate.nm.value;
//alert(ab);
 //phn= document.formValidate.ph.value;
 
 



function handleChange1()
{
	
	var bt= document.formValidate.grad.value;
	if(bt=='UG')
	{
		var dg1= new Option();
		dg1.value="BSc";
		dg1.text="BSc";
		document.formValidate.degree.options[0]=dg1;
		
		var dg2= new Option();
		dg2.value="B.Com";
		dg2.text="B.Com";
		document.formValidate.degree.options[1]=dg2;
		
		var dg3= new Option();
		dg3.value="B.A";
		dg3.text="B.A";
		document.formValidate.degree.options[2]=dg3;
		
		var dg4= new Option();
		dg4.value="B.E/ B.tech";
		dg4.text="B.E/ B.tech";
		document.formValidate.degree.options[3]=dg4;
	}
	
	else if(bt=='PG')
	{
		var dg1= new Option();
		dg1.value="M.Sc";
		dg1.text="M.Sc";
		document.formValidate.degree.options[0]=dg1;
		
		var dg2= new Option();
		dg2.value="M.Com";
		dg2.text="M.Com";
		document.formValidate.degree.options[1]=dg2;
		
		var dg3= new Option();
		dg3.value="MBA";
		dg3.text="MBA";
		document.formValidate.degree.options[2]=dg3;
		
		var dg4= new Option();
		dg4.value="M.E/ M.tech";
		dg4.text="M.E/ M.tech";
		document.formValidate.degree.options[3]=dg4;
	}
	
}



function calc()
{
	alert('Hi');
	ab= document.formValidate.nm.value;
alert(ab);
phn= document.formValidate.ph.value;

mailid= document.formValidate.ml.value;
grdLevel= document.formValidate.grad.value;
 var q1= document.formValidate.degree.selectedIndex;
 qual= document.formValidate.degree.options[q1].value;

	var dob= document.formValidate.dt.value;
	var myDob= new Date(dob);
	var d = new Date();
	var cYear = d.getFullYear();
	var bYear = myDob.getFullYear();
    age= cYear-bYear ;
	document.write("Age is :"+age);


 
 myWindow2 = window.open("", "MyWindow", "width=500,height=500");
	 
myWindow2.document.write("<p align=center>Details</p>");

myWindow2.document.write("Name : "+ab+"<br>");
myWindow2.document.write("<br>");
myWindow2.document.write("Age : "+age+"<br>");
myWindow2.document.write("<br>");
myWindow2.document.write("Phone : "+phn+"<br>");
myWindow2.document.write("<br>");
myWindow2.document.write("Email : "+mailid+"<br>");
myWindow2.document.write("<br>");
myWindow2.document.write("Graduation level : "+grdLevel+"<br>");
myWindow2.document.write("<br>");
myWindow2.document.write("Qualification : "+qual+"<br>");
myWindow2.document.write("<br>");

}


