package com.cg.appl.servlets;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//@WebServlet("/calInterest")
@WebServlet(urlPatterns="/calInterest",initParams={@WebInitParam(name="x",value= "20")})
public class CalInterest extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private float rateInterest;

	public void init() throws ServletException {
		ServletContext ctx = super.getServletContext();//variable made in xml has come
		String rateInterestStr=ctx.getInitParameter("rateInterest");//rateInterset from xml
		rateInterest = Float.parseFloat(rateInterestStr);
		System.out.println("From init"+ rateInterest);
		
		
	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		ServletContext ctx = super.getServletContext();//variable made in xml has come
		String rateInterestStr=ctx.getInitParameter("rateInterest");//rateInterset from xml
		rateInterest = Float.parseFloat(rateInterestStr);
		System.out.println("From service"+ rateInterest);
		System.out.println(ctx.getContextPath());
		System.out.println(ctx.getMajorVersion());
		System.out.println(ctx.getMinorVersion());
		System.out.println(ctx.getServerInfo());
		System.out.println(ctx.getServletContextName());
		
		
		ServletConfig cfg = super.getServletConfig();
		String xStr = cfg.getInitParameter("x");
		int x = Integer.parseInt(xStr);
		System.out.println(x);
		
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
