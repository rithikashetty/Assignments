package com.capgemini.appl.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.capgemini.appl.entities.User;
import com.capgemini.appl.exception.UserException;
import com.capgemini.appl.util.JdbcUtil;
import com.capgemini.appl.util.JndiUtil;

public class UserMasterDaoImpl implements UserMasterDao {
	//private JdbcUtil util;
	
	private JndiUtil util;
	
	public UserMasterDaoImpl() throws UserException{
		
		//util = new JdbcUtil();//object should be made in constructor
		
		util= new JndiUtil();
		
	}
	@Override
	public User getUserDetails(String userName) throws UserException {
		Connection connect=null;//should write in every method//import connection from java.sql
		PreparedStatement stmt=null;
		ResultSet rs=null;
		String qry="SELECT PASSWORD,USERFNAME from usermaster where USERNAME=?";
		
		try {
			
			
			connect = util.getConnection();
			 stmt = connect.prepareStatement(qry);
			stmt.setString(1,userName);
			rs= stmt.executeQuery();
			
			if(rs.next()){
				String password =rs.getString("PASSWORD");
				String fullName=rs.getString("USERFNAME");
				User user= new User(userName,password,fullName);
				return user;
				
			}
			else{
				
				throw new UserException("Wrong username");
			}
		} catch (SQLException e) {
		
			throw new UserException("JDBC Failed",e);
		}
		finally {
			try{
			if(rs!=null){
				
				rs.close();
			}
				if(stmt!=null){
					
					stmt.close();
					
				}
			if(connect!=null){
				
				connect.close();
			}
		}catch(SQLException e){
			
			throw new UserException("jdbc connection closing failed");
		}
			
		
}
	}
}
