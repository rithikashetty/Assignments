package com.capgemini.appl.listener;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

import com.capgemini.appl.exception.UserException;
import com.capgemini.appl.services.UserMasterService;
import com.capgemini.appl.services.UserMasterServicesImpl;

@WebListener
public class ProcureServiceListener implements ServletContextListener {

	private UserMasterService services;
	ServletContext ctx = null;
	


    public void contextInitialized(ServletContextEvent arg0)  { 
    	try {
			services = new UserMasterServicesImpl();
			
			ctx.setAttribute("services",services);
		} catch (UserException e) {

			ctx.log(e.getMessage());
			
		}
    }
    public void contextDestroyed(ServletContextEvent arg0)  { 
       
    	
    	
    }


    }
	

