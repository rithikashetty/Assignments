package com.capgemini.appl.util;

import java.sql.Connection;
import java.sql.SQLException;

public class TestUtil {

	public TestUtil() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
	
		JdbcUtil util = new JdbcUtil();
		try{
		Connection connect = util.getConnection();
		connect.close();
		}catch(SQLException e){
			e.printStackTrace();
			
		}
	}

}
