package com.capgemini.appl.servlets;

import java.io.IOException;








import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.appl.entities.User;
import com.capgemini.appl.exception.UserException;
import com.capgemini.appl.services.UserMasterService;
import com.capgemini.appl.services.UserMasterServicesImpl;

@WebServlet("*.do")
public class FrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserMasterService services;
	private RequestDispatcher dispatch;
	private String nextJsp;
	String message=null;
	ServletContext ctx = null;

	public void init() throws ServletException {
		ctx=super.getServletContext();
		services=(UserMasterService) ctx.getAttribute("services");
		
	/*	try {
			services = new UserMasterServicesImpl();
		} catch (UserException e) {
			RequestDispatcher dispatch = ctx.getRequestDispatcher("/error.jsp");
			ctx.log(e.getMessage());
			//e.printStackTrace();
		}
		*/
		
	}

	
	private void processRequest(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{
		String command=request.getServletPath();
		System.out.println("Command:"+command);
		
		switch(command){
		case "/login.do":{
			
			nextJsp = "/login.jsp";
			
			break;
		}
		
		case "/authenticate.do":{
			
			String uName = request.getParameter("userName");//retrives value from jsp
			String passwrd = request.getParameter("password");//retrives value from jsp
			
			
			
			try {
				boolean isAuthenticated=services.isUserAuthenticated(uName, passwrd);//passed to service layer which we got from jsp page
				if(isAuthenticated){
					//start session
					User user = services.getUserDetails(uName);
					System.out.println(user);
					HttpSession session = request.getSession(true);// select boolean parameter//session is created here
					System.out.println(session.getId());
					
					session.setAttribute("user", user);
					
					nextJsp ="/mainMenu.jsp";//from here session should be started
					
				}else{
					
					//System.out.println("No");
/*					System.out.println(uName);//prints user entered user name
					System.out.println(passwrd);//prints user entered password
					
*/					message ="wrong Credentilas.Enter again";
					request.setAttribute("errorMsg", message);
					nextJsp="/login.jsp";		
					
				}
			} catch (UserException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
				message = "User name does not exsit.";
				request.setAttribute("errorMsg", message);
				ctx.log(e.getMessage());
				nextJsp="/error.jsp";
				
			}
			break;
		}//end of case for authenticate.do
		
		case "/logout.do" :{
			
			HttpSession session = request.getSession(false);
			session.invalidate(); //destroys a session//space remove and removes id
			
			nextJsp="/login.jsp";//control will go to login.jsp
		}
		
		}
		
		dispatch = request.getRequestDispatcher(nextJsp);
		dispatch.forward(request, response);
		
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		processRequest(request,response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		processRequest(request,response);
		
	}
	public void destroy() {
		
	}

}
