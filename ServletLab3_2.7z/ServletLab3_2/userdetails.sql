CREATE TABLE RegisteredUsers ( firstname VARCHAR (20), lastname VARCHAR (30), password VARCHAR (12) UNIQUE, gender CHAR, skillset VARCHAR (40), city VARCHAR (12));
select * FROM RegisteredUsers;
