package com.capgemini.appl.servlet;



import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.appl.entities.UserDetails;
import com.capgemini.appl.exception.UserException;
import com.capgemini.appl.service.IUserDetailsService;
import com.capgemini.appl.service.UserDetailsServiceImpl;

@WebServlet("/frontController")
public class FrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	IUserDetailsService userService;


	public void init(ServletConfig config) throws ServletException {
		userService = new UserDetailsServiceImpl();
	}

	private void processRequest(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{

		UserDetails userd = new UserDetails();
		
		String firstName= request.getParameter("fname");
		String lastName=request.getParameter("lname");
		String password=request.getParameter("password");
		String genderVal=request.getParameter("gender");
		String[] skillVal=request.getParameterValues("skill");
		String  city=request.getParameter("cityselect");
		
		System.out.println(skillVal);
		String skillSet="";
		for(int i=0;i<skillVal.length;i++){
			skillSet=skillSet.concat(skillVal[i]);
			
		}
		
		char gen;
		if(genderVal.equals("male")){
			
			gen='M';
		}else{
			
			gen='F';
		}
		
		
		userd.setFirstName(firstName);
		userd.setLastName(lastName);
		userd.setPassword(password);
		userd.setGender(gen);
		userd.setSkillSet(skillSet);
		userd.setCity(city);
		
		System.out.println(userd);
		
		try {
			userService.addUserDetails(userd);
			
		} catch (UserException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}



	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request,response);
		
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		processRequest(request,response);
	}

}
