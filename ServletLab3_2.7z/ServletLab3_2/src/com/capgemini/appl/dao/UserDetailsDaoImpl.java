package com.capgemini.appl.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.capgemini.appl.entities.UserDetails;
import com.capgemini.appl.exception.UserException;
import com.capgemini.appl.util.DbUtil;


public class UserDetailsDaoImpl implements IUserDetailsDao {

	@Override
	public boolean addUseDetails(UserDetails userd) throws UserException {
		Connection conn=null;
		PreparedStatement pstm=null;
		String query = "INSERT INTO RegisteredUsers VALUES(?,?,?,?,?,?)";
		
		try {
			conn=DbUtil.obtainconnection();
			pstm=conn.prepareStatement(query);
			pstm.setString(1,userd.getFirstName());
			pstm.setString(2, userd.getLastName());
			pstm.setString(3,userd.getPassword());
			pstm.setString(4,String.valueOf(userd.getGender()));
			pstm.setString(5, userd.getSkillSet());
			pstm.setString(6, userd.getCity());
			int status=pstm.executeUpdate();
			
		} catch (UserException e) {
			throw new UserException("Problem Occured");
			//e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		finally{
			try{
				
				pstm.close();
				conn.close();
				
			}catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();	
		}
		}
		return false;
	}
	


}
