package com.capgemini.appl.tests;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.appl.entities.User;
import com.capgemini.appl.exception.UserException;
import com.capgemini.appl.services.UserMasterService;
import com.capgemini.appl.services.UserMasterServicesImpl;

public class TestUser {

	private static UserMasterService services;
	@BeforeClass
	public static  void initialize() {
		
		services = new UserMasterServicesImpl();
		
	}
	@Test
public void testGetUserDetails(){
	
	try {
		User user=services.getUserDetails("a");
		String actualPassword = "a";
		Assert.assertEquals(user.getPassword(),actualPassword);
	} catch (UserException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}
