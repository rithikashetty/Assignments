package com.capgemini.appl.servlets;

import java.io.IOException;



import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.appl.services.UserMasterService;
import com.capgemini.appl.services.UserMasterServicesImpl;


@WebServlet("/authenticate")
public class Authenticate extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserMasterService services;
	
	public void init() throws ServletException {
		services=new UserMasterServicesImpl();
		
		
	}


/*	public void init(ServletConfig config) throws ServletException {
		services=new UserMasterServicesImpl();
		
		
	}*///real life cycle


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		
		
	}
	
	
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse resp)
			throws ServletException, IOException {
		
		String uName = request.getParameter("userName");//retrives value from jsp
		String passwrd = request.getParameter("password");//retrives value from jsp
		RequestDispatcher dispatch =  null;
		String nextJsp = null;
		String message=null;
		
		
		try {
			boolean isAuthenticated=services.isUserAuthenticated(uName, passwrd);//passed to service layer which we got from jsp page
			if(isAuthenticated){
				//System.out.println("Yes");
				nextJsp ="/mainMenu.jsp";
				/*dispatch = request.getRequestDispatcher("/mainMenu.jsp");//root folder ke andar
				dispatch.forward(request, resp);//do post ka request response
			*/
			}else{
				
				//System.out.println("No");
				
				message ="wrong Credentilas.Enter again";
				request.setAttribute("errorMsg", message);
				nextJsp="/login.jsp";

			/*	dispatch = request.getRequestDispatcher("/login.jsp");//root folder ke andar
				dispatch.forward(request, resp);//do post ka request,response
*/			
				
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			message = "User name does not exsit.";
			request.setAttribute("errorMsg", message);
			nextJsp="/error.jsp";
			
		}dispatch = request.getRequestDispatcher(nextJsp);//root folder ke andar so /
		dispatch.forward(request, resp);//do post ka request response
		
		/*System.out.println("Username:"+uName);//prints in console
		System.out.println("Password"+passwrd);//prints in console
*/		
	
		
	}


	public void destroy() {
		
	}



}
