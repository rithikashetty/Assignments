package com.capgemini.appl.util;

import java.io.FileInputStream;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

import oracle.jdbc.pool.OracleDataSource;

public class JdbcUtil {
	
	//private Properties props;//import properties from java.util
	private OracleDataSource dataSource;//datasource manages connection pool//import it from oracle jdbc pool

	public JdbcUtil() {
		/*props = new Properties();//constructor//comment this if no properties written
		InputStream in=null;//constructor//comment this if no properties written
*/		
		try {
			 /*in = new FileInputStream("D:\\Training\\Spring4Practice\\Module3\\Web020LoginSimple\\src\\oracle.properties");
			props.load(in);//constructor//comment this if no properties written
			
			dataSource = new OracleDataSource();//will take url uname upass and will make connection pool
			dataSource.setURL(props.getProperty("oracle.url"));//can write "jdbc:oracle:thin:@10.125.6.62:1521:ORCL11G"
			dataSource.setUser(props.getProperty("oracle.uname"));
			dataSource.setPassword(props.getProperty("oracle.upass"));
			dataSource.setDriverType("oracle");*/
			
			
			dataSource = new OracleDataSource();//will take url uname upass and will make connection pool
			dataSource.setURL("jdbc:oracle:thin:@10.125.6.62:1521:ORCL11G");//can write "jdbc:oracle:thin:@10.125.6.62:1521:ORCL11G"
			dataSource.setUser("labg104trg7");
			dataSource.setPassword("labg104oracle");
			dataSource.setDriverType("oracle");
			
		}/* catch (FileNotFoundException e) {//comment all catch and finally if no  properties file is written
*//*			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}*/catch (SQLException e) {//except this
			e.printStackTrace();
		}
		
		/*finally{//comment this if no properties
			
			try {
				in.close();//file is closed in same class where file is opened
			} catch (IOException e) {
				
				e.printStackTrace();
			}
		}*/
		
		
	}
	
	public Connection getConnection() throws SQLException{//import connection from java.sql
		
		return dataSource.getConnection();//connections are already established.no opening and closing connection.threadsafe connection
	}


	@Override
	protected void finalize() throws Throwable {
		dataSource.close();
		super.finalize();
	}

	
	
}
