package com.capgemini.appl.services;

import com.capgemini.appl.dao.UserMasterDao;
import com.capgemini.appl.dao.UserMasterDaoImpl;
import com.capgemini.appl.entities.User;
import com.capgemini.appl.exception.UserException;

public class UserMasterServicesImpl implements UserMasterService {
	private UserMasterDao dao;
	
	public UserMasterServicesImpl() {
		
		dao=new UserMasterDaoImpl();
		
	}

	@Override
	public User getUserDetails(String userName) throws UserException {
		
		return dao.getUserDetails(userName);
	}

	@Override
	public boolean isUserAuthenticated(String userName, String password) throws UserException {
		
		User user = dao.getUserDetails(userName);
		if(password.equals(user.getPassword()))
		{
			return true;
		}
		else
		{
		return false;
	
		}

	
}
}
