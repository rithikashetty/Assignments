select * from emp;
drop table user;
create table usermaster(USERNAME varchar2(15) PRIMARY KEY,
PASSWORD varchar2(15),
USERFNAME varchar2(40));

insert into users(USERNAME,PASSWORD,USERFNAME)VALUES('a','a','Chandra');
insert into users(USERNAME,PASSWORD,USERFNAME)VALUES('b','b','Mitra');

SELECT * FROM usermaster;

create table usermaster(USERNAME varchar2(15) PRIMARY KEY,
PASSWORD varchar2(15),
USERFNAME varchar2(40));

insert into usermaster(USERNAME,PASSWORD,USERFNAME)VALUES('a','a','Chandra');
insert into usermaster(USERNAME,PASSWORD,USERFNAME)VALUES('b','b','Mitra');

SELECT * FROM usermaster;