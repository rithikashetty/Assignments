package com.cg.ebill.dao;

import com.cg.ebill.dto.BillDetails;
import com.cg.ebill.dto.User;
import com.cg.ebill.exception.BillException;

public interface IEBillDao {
	
	User getUserDetails(String userName) throws BillException;

	public int addBillDetail(int consumerno, BillDetails billDetail) throws BillException;

}
