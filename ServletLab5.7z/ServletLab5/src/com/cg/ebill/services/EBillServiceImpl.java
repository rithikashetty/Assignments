package com.cg.ebill.services;

import com.cg.ebill.dao.EBillDaoImpl;
import com.cg.ebill.dao.IEBillDao;
import com.cg.ebill.dto.BillDetails;
import com.cg.ebill.dto.User;
import com.cg.ebill.exception.BillException;


public class EBillServiceImpl implements IEbillService {
	
	private IEBillDao billdao;

	public EBillServiceImpl() {
		billdao = new EBillDaoImpl();
		
	}

	@Override
	public boolean isUserAuthenticated(String userName, String password) throws BillException {
		User user =billdao.getUserDetails(userName);
		if(password.equals(user.getPassword()))
		{
			return true;
		}
		else
		{
		return false;
	
		}
	}

	@Override
	public User getUserDetails(String userName) throws BillException {
		
		return billdao.getUserDetails(userName);
	}

	@Override
	public int addBillDetail(int consumerno, BillDetails billDetail) throws BillException {
		
		return billdao.addBillDetail(consumerno,billDetail);
	}

}
